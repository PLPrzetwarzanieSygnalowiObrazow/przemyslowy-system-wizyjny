PROGRAM_DESCRIPTION = """
An industrial vision system that will detect and then classify jewelry,
placed on a moving conveyor belt in real time.
"""

VIDEO_FILE_PATH_HELPER = """
Relative or absolute path to video file to analyze.
"""

START_FRAME_NUMBER_HELPER = """
Frame number from which program starts analysis.
"""
